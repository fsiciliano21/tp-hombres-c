#Dependencias necesarias para conectar a mysql desde flask.

pip install flask_sqlalchemy

pip install mysql-connector-python

