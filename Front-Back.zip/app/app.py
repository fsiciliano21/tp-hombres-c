from flask import Flask, render_template
import requests



API_URL = 'http://localhost:5000/api/v1/'

app = Flask(__name__)

@app.route("/")
def home():
    try:
        response = requests.get(API_URL+'alumnos')
        response.raise_for_status()
        alumnos = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data: {e}")
        alumnos = []

    return render_template('home.html', alumnos=alumnos)

if __name__ == "__main__":
    app.run("127.0.0.1", port="5001", debug=True)